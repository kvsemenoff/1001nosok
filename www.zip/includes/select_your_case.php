<section class="df-bg-orange">
	<div class="container">		
		<div class="row">			
			<h2>ВЫбери свой кейс с носками</h2>
			<div class="df-box-case">
				<span class="df-span1">Кейс носков</span><br>
				<span class="df-span2 df-tovar-name">«Хлопок»</span>
				<div class="df-case">
					<div class="df-tovar-picture">
						<img src="img/df-case1.png" alt="">
					</div>
					<span class="df-vigodno">Выгодно!</span>
					<span class="df-chose">Выбери свой кейс</span>
					<input type="hidden" class="hprice" value="">
					<input type="hidden" class="hpare" value="">
					<div class="df-inputs">
						<label>
							<input class="checkbox" type="radio" name="checkbox1" value="">
							<span class="checkbox-custom"></span>
							<span class="label"></span>
						</label>
						<span class="df-price"><span class="df-price-d">1 399 р.</span><span class="df-cur-pare">— 30 пар в кейсе </span></span><br>
						<label>
							<input class="checkbox" type="radio" name="checkbox1" value="" checked>
							<span class="checkbox-custom"></span>
							<span class="label"></span>
						</label>
						<span class="df-price"><span class="df-price-d">1 799 р.</span><span class="df-cur-pare">— 50 пар в кейсе </span></span><br>
						<label>
							<input class="checkbox" type="radio" name="checkbox1" value="">
							<span class="checkbox-custom"></span>
							<span class="label"></span>
						</label>
						<span class="df-price"><span class="df-price-d">2 499 р.</span><span class="df-cur-pare">— 100 пар в кейсе </span></span><br>
						<a href="#thanks2"  name="tovar" class="df-link">100% хлопок заказать</a>
					</div>						
				</div>
			</div>				
			<div class="df-box-case">
				<span class="df-span1">Кейс носков</span><br>
				<span class="df-span2 df-tovar-name">«Бамбуковые носки»</span>
				<div class="df-case">

					<div class="df-tovar-picture">
						<img src="img/df-case1.png" alt="">
					</div>
					<span class="df-vigodno">Бизнес класс!</span>
					<span class="df-chose">Выбери свой кейс</span>
					<input type="hidden" class="hprice" value="">
					<input type="hidden" class="hpare" value="">
					<div class="df-inputs">
						<label>
							<input class="checkbox" type="radio" name="checkbox2" checked>
							<span class="checkbox-custom"></span>
							<span class="label"></span>
						</label>
						<span class="df-price"><span class="df-price-d">1 799 р.</span><span>— 30 пар в кейсе </span></span><br>
						<label>
							<input class="checkbox" type="radio" name="checkbox2" value="">
							<span class="checkbox-custom"></span>
							<span class="label"></span>
						</label>
						<span class="df-price"><span class="df-price-d">2 499 р.</span><span class="df-cur-pare">— 50 пар в кейсе </span></span><br>
						<label>
							<input class="checkbox" type="radio" name="checkbox2" value="">
							<span class="checkbox-custom"></span>
							<span class="label"></span>
						</label>
						<span class="df-price"><span class="df-price-d">3 999 р.</span><span class="df-cur-pare">— 100 пар в кейсе </span></span><br>
						<a href="#thanks2" name="tovar" class="df-link">Бамбуковые носки заказать</a>
					</div>						
				</div>
			</div>
			<div class="df-box-case">
				<span class="df-span1">Кейс носков</span><br>
				<span class="df-span2 df-tovar-name">«Хлопок - Люкс»</span>
				<div class="df-case">
					<div class="df-tovar-picture">
						<img src="img/df-case1.png" alt="">
					</div>
					<span class="df-vigodno">Премиум- класс</span>
					<span class="df-chose df-tovar-name">Выбери свой кейс</span>
					<input type="hidden" class="hprice" value="">
					<input type="hidden" class="hpare" value="">
					<div class="df-inputs">
						<label>
							<input class="checkbox" type="radio" name="checkbox3" checked>
							<span class="checkbox-custom"></span>
							<span class="label"></span>
						</label>
						<span class="df-price"><span class="df-price-d">1 999 р.</span><span class="df-cur-pare">— 30 пар в кейсе </span></span><br>
						<label>
							<input class="checkbox" type="radio" name="checkbox3" >
							<span class="checkbox-custom"></span>
							<span class="label"></span>
						</label>
						<span class="df-price"><span class="df-price-d">2 999 р.</span><span class="df-cur-pare">— 50 пар в кейсе </span></span><br>
						<label>
							<input class="checkbox" type="radio" name="checkbox3">
							<span class="checkbox-custom"></span>
							<span class="label"></span>
						</label>
						<span class="df-price"><span class="df-price-d">4 999 р.</span><span class="df-cur-pare">— 100 пар в кейсе </span></span><br>
						<a href="#thanks2" name="tovar" class="df-link">Хлопок - Люкс заказать</a>
					</div>						
				</div>
			</div>
			<div class="df-box-case">
				<span class="df-span1">Кейс носков микс</span><br>
				<span class="df-span2 df-tovar-name">«Бамбук MIX»</span>
				<div class="df-case">
					<div class="df-tovar-picture">
						<img src="img/df-case1.png" alt="">
					</div>
					<span class="df-vigodno">Выгодно!</span>
					<span class="df-chose">Выбери свой кейс</span>
					<input type="hidden" class="hprice" value="">
					<input type="hidden" class="hpare" value="">
					<div class="df-inputs">
						<label>
							<input class="checkbox" type="radio" name="checkbox4" checked>
							<span class="checkbox-custom"></span>
							<span class="label"></span>
						</label>
						<span class="df-price"><span class="df-price-d">1 799 р.</span><span class="df-cur-pare">— 30 пар в кейсе </span></span><br>
						<label>
							<input class="checkbox" type="radio" name="checkbox4" >
							<span class="checkbox-custom"></span>
							<span class="label"></span>
						</label>
						<span class="df-price"><span class="df-price-d">2 499 р.</span><span class="df-cur-pare">— 50 пар в кейсе </span></span><br>
						<label>
							<input class="checkbox" type="radio" name="checkbox4">
							<span class="checkbox-custom"></span>
							<span class="label"></span>
						</label>
						<span class="df-price"><span class="df-price-d">3 999 р.</span><span class="df-cur-pare">— 100 пар в кейсе </span></span><br>
						<a href="#thanks2" name="tovar" class="df-link">Бамбук MIX заказать</a>
					</div>

				</div>
			</div>
			<div class="df-box-case">
				<span class="df-span1">Кейс носков микс</span><br>
				<span class="df-span2 df-tovar-name">«Носки ХБ MIX»</span>
				<div class="df-case">
					<div class="df-tovar-picture">
						<img src="img/df-case1.png" alt="">
					</div>
					<span class="df-vigodno">Комфортно!</span>
					<span class="df-chose">Выбери свой кейс</span>
					<input type="hidden" class="hprice" value="">
					<input type="hidden" class="hpare" value="">
					<div class="df-inputs">
						<label>
							<input class="checkbox" type="radio" name="checkbox5" checked>
							<span class="checkbox-custom"></span>
							<span class="label"></span>
						</label>
						<span class="df-price"><span class="df-price-d">1 499 р.</span><span class="df-cur-pare">— 30 пар в кейсе </span></span><br>
						<label>
							<input class="checkbox" type="radio" name="checkbox5" >
							<span class="checkbox-custom"></span>
							<span class="label"></span>
						</label>
						<span class="df-price"><span class="df-price-d">1 899 р.</span><span class="df-cur-pare">— 50 пар в кейсе </span></span><br>
						<label>
							<input class="checkbox" type="radio" name="checkbox5">
							<span class="checkbox-custom"></span>
							<span class="label"></span>
						</label>
						<span class="df-price"><span class="df-price-d">2 799 р.</span><span class="df-cur-pare">— 100 пар в кейсе </span></span><br>
						<a href="#thanks2" name="tovar" class="df-link">Носки ХБ MIX заказать</a>
					</div>
					
				</div>
			</div>
			<div class="df-box-case">
				<span class="df-span1">Кейс носков</span><br>
				<span class="df-span2 df-tovar-name">«Шерсть»</span>
				<div class="df-case">
					<div class="df-tovar-picture">
						<img src="img/df-case1.png" alt="">
					</div>
					<span class="df-vigodno">идеально для зимы!</span>
					<span class="df-chose">Выбери свой кейс</span>
					<input type="hidden" class="hprice" value="">
					<input type="hidden" class="hpare" value="">
					<div class="df-inputs">
						<label>
							<input class="checkbox" type="radio" name="checkbox6" checked>
							<span class="checkbox-custom"></span>
							<span class="label"></span>
						</label>
						<span class="df-price"><span class="df-price-d">2 299 р.</span><span class="df-cur-pare">— 30 пар в кейсе </span></span><br>
						<label>
							<input class="checkbox" type="radio" name="checkbox6" >
							<span class="checkbox-custom"></span>
							<span class="label"></span>
						</label>
						<span class="df-price"><span class="df-price-d">3 199 р.</span><span class="df-cur-pare">— 50 пар в кейсе </span></span><br>
						<label>
							<input class="checkbox" type="radio" name="checkbox6">
							<span class="checkbox-custom"></span>
							<span class="label"></span>
						</label>
						<span class="df-price"><span class="df-price-d">5 399 р.</span><span class="df-cur-pare">— 100 пар в кейсе </span></span><br>
						<a href="#thanks2" name="tovar" class="df-link">Шерсть заказать</a>
					</div>
					
				</div>
			</div>
		</div>
	</div>
</section>		