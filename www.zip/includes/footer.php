<div class="db-footer-block">
<div class="db-footer-all">
	<div class="db-tel">
		8 (499) 322-70-17		
	</div>
	<div class="db-link-one">
		<ul>
			<li><a href="#">Кейс ХБ</a></li>
			<li><a href="#">Кейс "Бамбук"</a></li>
			<li><a href="#">Шерстяные в кейсе</a></li>
			<li><a href="#">Кейс с носками</a></li>
			<li><a href="#">Кейс на год</a></li>
			<li><a href="#">Кейс "Микс"</a></li> 
		</ul>
		</div>
		<div class="clearfix"></div>	
		<div class="db-link-two">
		<ul>
			<li><a href="#">Оптом в кейсах</a></li>
			<li><a href="#">Разнообрезие</a></li>
			<li><a href="#">От лучших поставщиков</a></li>
		</ul>
	</div>
	</div>
</div>

<div id="mask"></div>
<div id="thanks" class="window">
	<div class="dd-form-wrap">
		<div class="form-wrap-main">
			<div class="dd-close"></div>
			<div class="form-wrap-red">
				<div class="form-title dd-padding-bottom">
					Спасибо за заявку!
				</div>
				<div class="dd-form-txt dd-padding-bottom">
					Наш менеджер свяжется с вами в ближайшее время!
				</div>
			</div>
		</div>
	</div>
</div>
<a href="#thanks" name="modal"></a>
<a href="#thanks2" name="modal"></a>
<div id="thanks2" class="window">
<div class="dd-close2"></div>
	<div class="db-all">
	<div id="db-window-img" class="db-window-img"><!-- <img src="../img/db-socks.png" alt="image"> --></div>
	<div class="db-content-window">
		<div class="db-h-content">

			<span class="db-h-one">Кейс носков</span><br>
			<span id="db-h-two" class="db-h-two"><!-- "ХЛОПОК1" --></span>
		</div>
		<div class="db-price-content">
			<span id="db-price-one" class="db-price-one">Цена: 1 799 р.</span><br>
			<span id="db-price-two" class="db-price-two"><!-- 50 пар в кейсе --></span>
		</div>
		<div class="db-form-content">
			<form action="thanks.php" method="post" class="form1">
				<input type="text" name="uname" placeholder="Ваше имя"><br>
				<input type="text" name="phone" placeholder="Номер телефона" class="phone"><br>
				<input type="submit" name="submit" value="100% ХЛОПОК ЗАКАЗАТЬ">
			</form>		
		</div>
	</div>
</div>
</div>