<div class="df-bg-noski">
	<div class="container">		
		<div class="row">
			<div class="col-md-12">
				<h2>В чем удобство?</h2>
			</div>
			<div class="col-md-6 col-xs-12 col-sm-6">
				<div class="df-2box">
					<div class="df-left">
						<span>Куча разных целых и рваных носков</span>
						<span>Каждый день надо искать пару</span>
						<span>Высокие цены в магазинах (от 100 руб.)</span>
					</div>
				</div>
			</div>
			<div class="col-md-6 col-xs-12 col-sm-6">
				<div class="df-2box">
					<div class="df-right">
						<span>От 30 до 100 пар носков в кейсе</span>
						<span>Все носки собраны в одном месте</span>
						<span>Низкая цена (от 25 руб. за пару)</span>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>		