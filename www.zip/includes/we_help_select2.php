<section class="db-all-container db-all-container2">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
					<span class="db-header">Оставьте заявку и мы поможем выбрать</span>
			</div>
			<div class="clearfix"></div>
			<form action="#" method="post" class="form1">
				<div class="col-md-4">
					<div class="db-input-one">
						<input type="text" placeholder="Ваше имя" name="uname">
					</div>
				</div>
				<div class="col-md-4">
					<div class="db-input-two">
						<input type="text" placeholder="Номер телефона" name="phone" class="phone">
					</div>
				</div>
				<div class="col-md-4">
					<div class="db-input-three">
						<input type="submit" value="Отправить" name="submit">
					</div>
				</div>
				<div class="clearfix"></div>
			</form>

		</div>
	</div>
</section>