<section class="dd-sertifikat">
	<div class="dd-content-sertifikat">
		<div class="dd-title">
			<span>Мы и наши фабрики работаем официально</span>
		</div>
		<div class="dd-images">
			<div class="dd-serificat-img">
				<img src="img/s1.jpg" alt="">
			</div>
			<div class="dd-serificat-img dd-serificat-img1">
				<img src="img/s2.jpg" alt="">
			</div>
			<div class="dd-serificat-img dd-serificat-img2">
				<img src="img/s3.jpg" alt="">
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</section>