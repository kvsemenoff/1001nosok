<section class="dd-how-look-wrap">
	<div class="my-container">
		<div class="dd-how-look">
			<div class="dd-how-look-img">
				<div class="dd-title">
					<span>Как выглядит кейс?</span>
				</div>
				<img class="img-responsive" src="img/howlook.png" alt="">
			</div>
			<div class="dd-look-txt dd-look-txt1">
				<span>Качественно</span><br>
				<span>Такой кейс носков внешне выглядит по-настоящему мужским подарком.</span>
			</div>
			<div class="dd-look-txt dd-look-txt2">
				<span>Солидно</span><br>
				<span>30 - 100 пар носков упаковываются в черный лакированный кейс из твердого картона.</span>
			</div>
			<div class="dd-look-txt dd-look-txt3">
				<span>Стильно</span><br>
				<span>Он будет удобен при переносе и отлично подойдет для хранения носков.</span>
			</div>
		</div>
	</div>
</section>